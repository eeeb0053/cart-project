import React, { useEffect, useState, useCallback } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { Row, Col, Input, Rate, Checkbox, Button } from 'antd';
import { FormControl, RadioGroup, DragAndDropUploader } from 'components/index';
import { Form, Label, GroupTitle, Description } from 'container/review/Review.style';
import axios from 'axios';

const ReviewForm = () => {
  const { control, register, errors, setValue, handleSubmit } = useForm();
  const [review,setReview ] = useState({
    reviewTitle : "",
    reviewContent : "",
    regDate : "",
    score : 0,
  })

  const{reviewTitle, reviewContent, regDate, score} = review
  const onChange = useCallback(e => {
    setReview({...review, [e.target.name]: e.target.value})
  })
 
  const desc = ['1', '2', '3', '4', '5'];

  const onSubmit = e => {
    // e.preventDefault()
    axios({
        url: `http://localhost:8080/reviews`,
        method: 'post',
        headers: {'Content-Type':'application/json','Authorization': 'JWT fefege...'},
        data: { reviewTitle, reviewContent, regDate, score }
    }).then(res => {
        alert(`성공`)
        window.location.reload()
    }).catch(err => {
        alert(err.response)
    })
  };

  return (
    <Form onSubmit={e => e.preventDefault()}>
      <FormControl
        label="별점"
        htmlFor="score"
        error={errors.score && <span>별점을 입력해주세요!</span>}
      >
        <span>
        <Rate 
          tooltips={desc} onChange={ onChange }
          id="score"
          name="score" value={score}
          defaultValue=""
        />
          {score ? <span className="ant-rate-text">{desc[score - 1]}</span> : ''}
        </span>
      </FormControl>
      <FormControl
        label="제목"
        htmlFor="reviewTitle"
        error={errors.reviewTitle && <span>This field is required!</span>}
      >
        <Input 
          onChange = {onChange}
          id="reviewTitle"
          name="reviewTitle" value={reviewTitle}
          defaultValue=""
          control={control}
          placeholder="전시회 제목을 입력해주세요"
          rules={{
            required: true
          }}/>
      </FormControl>
      <FormControl
        label="내용"
        htmlFor="reviewContent"
        error={errors.reviewContent && <span>This field is required!</span>}
      >
        <Input.TextArea 
          rows={5} onChange = {onChange}
          id="reviewContent"
          name="reviewContent" value={reviewContent}
          defaultValue=""
          control={control}
          placeholder="전시회는 어떠셨나요?"
          rules={{
            required: true,
          }}
        />
      </FormControl>
      <FormControl>
        <Controller
          name="termsAndCondition"
          onChange={([e]) => {
            return e.target.checked;
          }}
          as={
            <Checkbox>
              게시판 운영 규정에 어긋난다고 판단되는 게시글은 사전 통보없이 블라인드 처리될 수 있습니다.
              특히 티켓 매매 및 양도의 글은 발견 즉시 임의 삭제되며 전화번호, 이메일 등의 개인정보는 
              악용될 우려가 있으므로 게시를 삼가 주시기 바랍니다.
              사전 경고에도 불구하고 불량 게시물을 계속적으로 게재한 게시자의 경우 C:ART 게시판 
              작성 권한이 제한됩니다.
            </Checkbox>
          }
          control={control}
        />
      </FormControl>
      <FormControl className="submit-container">
        <Button htmlType="submit" type="primary" size="large"
                onClick = {onSubmit}>
          작성 완료
        </Button>
      </FormControl>
    </Form>
  );
};

export default ReviewForm;